
select 'ztubt_toto_placedbettransactionlineitem' as table_name, count(*) as row_count from ztubt_toto_placedbettransactionlineitem
union all
select 'ztubt_validatedbetticket' as table_name, count(*) as row_count from ztubt_validatedbetticket
union all
select 'ztubt_product' as table_name, count(*) as row_count from ztubt_product
union all
select 'ztubt_validatedbetticketlifecyclestate' as table_name, count(*) as row_count from ztubt_validatedbetticketlifecyclestate
union all
select 'ztubt_placedbettransactionheaderlifecyclestate' as table_name, count(*) as row_count from ztubt_placedbettransactionheaderlifecyclestate
union all
select 'ztubt_horse_placedbettransactionlineitem' as table_name, count(*) as row_count from ztubt_horse_placedbettransactionlineitem
union all
select 'ztubt_getbusinessdate_perhost' as table_name, count(*) as row_count from ztubt_getbusinessdate_perhost
union all
select 'ZTUBT_TERMINAL' as table_name, count(*) as row_count from ZTUBT_TERMINAL
union all
select 'ZTUBT_VALIDATIONTYPE' as table_name, count(*) as row_count from ZTUBT_VALIDATIONTYPE
union all
select 'ZTUBT_LOCATION' as table_name, count(*) as row_count from ZTUBT_LOCATION
union all
select 'ztubt_cancelledbetticket' as table_name, count(*) as row_count from ztubt_cancelledbetticket
union all
select 'ztubt_cancelledbetticketlifecyclestate' as table_name, count(*) as row_count from ztubt_cancelledbetticketlifecyclestate
union all
select 'ZTUBT_PAYMENTDETAIL' as table_name, count(*) as row_count from ZTUBT_PAYMENTDETAIL
union all
select 'ZTUBT_PLACEDBETTRANSACTIONHEADER' as table_name, count(*) as row_count from ZTUBT_PLACEDBETTRANSACTIONHEADER
union all
select 'ZTUBT_SWEEP_PLACEDBETTRANSACTIONLINEITEM' as table_name, count(*) as row_count from ZTUBT_SWEEP_PLACEDBETTRANSACTIONLINEITEM
union all
select 'ZTUBT_SWEEP_PLACEDBETTRANSACTIONLINEITEMNUMBER' as table_name, count(*) as row_count from ZTUBT_SWEEP_PLACEDBETTRANSACTIONLINEITEMNUMBER
union all
select 'ZTUBT_GETBUSINESSDATE_PERHOST' as table_name, count(*) as row_count from ZTUBT_GETBUSINESSDATE_PERHOST
union all
select 'ztubt_salescomconfig' as table_name, count(*) as row_count from ztubt_salescomconfig
union all
select 'ztubt_sap_product' as table_name, count(*) as row_count from ztubt_sap_product;
union all
select 'ZTUBT_CHAIN' as table_name, count(*) as row_count from ZTUBT_CHAIN;
union all
select 'ztubt_gstconfig' as table_name, count(*) as row_count from ztubt_gstconfig;
union all
select 'ZTUBT_PRODUCT' as table_name, count(*) as row_count from ZTUBT_PRODUCT;